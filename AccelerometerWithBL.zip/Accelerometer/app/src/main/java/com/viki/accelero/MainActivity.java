package com.viki.accelero;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bluetooth.communicator.BluetoothCommunicator;
import com.bluetooth.communicator.Peer;
import com.viki.accelero.fragments.ConversationFragment;
import com.viki.accelero.fragments.PairingFragment;
import com.viki.accelero.kdgaugeview.KdGaugeView;
import com.viki.accelero.tools.Tools;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    KdGaugeView gaugeView;
    BatteryView batteryView;
    Indicator mHorizontalBattery;
    TextView timeTextView;
    TextView tempAndLocTextView;
    public ImageView blIndicator,wifiIndicator,cellularIndicator,answerCall,dismissCall;
    //SensorManager mSensorManager;
    //Sensor mTemperature;
    private GpsTracker gpsTracker;
    int[] colorArr;
    float[] changeValArr;
    Random randomNum;
    int batteryVal = 0;
    String[] days = new String[]{"Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"};
    public static final int PAIRING_FRAGMENT = 0;
    public static final int CONVERSATION_FRAGMENT = 1;
    public static final int DEFAULT_FRAGMENT = PAIRING_FRAGMENT;
    public static final int NO_PERMISSIONS = -10;
    private static final int REQUEST_CODE_REQUIRED_PERMISSIONS = 2;
    public static final String[] REQUIRED_PERMISSIONS = new String[]{
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_COARSE_LOCATION,
    };
    private Global global;
    private int currentFragment = -1;
    private ArrayList<Callback> clientsCallbacks = new ArrayList<>();
    private CoordinatorLayout fragmentContainer;
    public CardView callIndicator;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        randomNum = new Random();
        setContentView(R.layout.activity_main);
        gaugeView = findViewById(R.id.speedMeter);
        batteryView = findViewById(R.id.battery);
        mHorizontalBattery = findViewById((R.id.horizontalBattery));
        tempAndLocTextView = findViewById((R.id.tempAndLocTextView));
        timeTextView = findViewById((R.id.timeTextView));
        blIndicator = findViewById((R.id.blIndicator));
        wifiIndicator = findViewById((R.id.wifiIndicator));
        cellularIndicator = findViewById((R.id.cellularIndicator));
        answerCall = findViewById((R.id.answerCall));
        dismissCall = findViewById((R.id.dismissCall));
        callIndicator = findViewById((R.id.callIndicator));
        callIndicator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callIndicator.setVisibility(View.INVISIBLE);
            }
        });
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH_SCAN},1);
            }
        }
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},2);
            }
        }
        global = (Global) getApplication();

        // Clean fragments (only if the app is recreated (When user disable permission))
        FragmentManager fragmentManager = getSupportFragmentManager();
        if (fragmentManager.getBackStackEntryCount() > 0) {
            fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }

        // Remove previous fragments (case of the app was restarted after changed permission on android 6 and higher)
        List<Fragment> fragmentList = fragmentManager.getFragments();
        for (Fragment fragment : fragmentList) {
            if (fragment != null) {
                fragmentManager.beginTransaction().remove(fragment).commit();
            }
        }

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        fragmentContainer = findViewById(R.id.fragment_container);

        global.getBluetoothCommunicator().addCallback(new BluetoothCommunicator.Callback() {
            @Override
            public void onAdvertiseStarted() {
                super.onAdvertiseStarted();
                if (global.getBluetoothCommunicator().isDiscovering()) {
                    notifySearchStarted();
                }
            }

            @Override
            public void onDiscoveryStarted() {
                super.onDiscoveryStarted();
                if (global.getBluetoothCommunicator().isAdvertising()) {
                    notifySearchStarted();
                }
            }

            @Override
            public void onAdvertiseStopped() {
                super.onAdvertiseStopped();
                if (!global.getBluetoothCommunicator().isDiscovering()) {
                    notifySearchStopped();
                }
            }

            @Override
            public void onDiscoveryStopped() {
                super.onDiscoveryStopped();
                if (!global.getBluetoothCommunicator().isAdvertising()) {
                    notifySearchStopped();
                }
            }
        });
        //mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
       // mTemperature = mSensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE); // requires API level 14.
       /* try {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 101);
            }
        } catch (Exception e){
            e.printStackTrace();
        }*/
        try {
            updateTimeAtEveryMin();
            Timer t = new Timer();
            TimerTask tt = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            setGaugeSpeedAndColors();
                        }
                    });
                }

                ;
            };
            t.scheduleAtFixedRate(tt, 500, 3000);
            Timer t1 = new Timer();
            TimerTask tt1 = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            setBatteryValues();
                        }
                    });
                }

                ;
            };
            t1.scheduleAtFixedRate(tt1, 2000, 6000);
//            Timer tempTask = new Timer();
//            TimerTask tempTask1 = new TimerTask() {
//                @Override
//                public void run() {
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            String location = getLocation();
//                            if (location != null && !location.isEmpty())
//                                tempAndLocTextView.setText(getLocation() + getResources().getString(R.string.celsius));
//                        }
//                    });
//                }
//
//                ;
//            };
//            tempTask.scheduleAtFixedRate(tempTask1, 0, 10000);
        }catch (Exception e){
            e.printStackTrace();
        }
    }




    @Override
    protected void onResume() {
        super.onResume();
        /*if (mTemperature != null) {
            mSensorManager.registerListener(this, mTemperature, SensorManager.SENSOR_DELAY_NORMAL);
        } else {
            Toast.makeText(this, "No Ambient Temperature Sensor !", Toast.LENGTH_LONG).show();
        }*/

    }

    @Override
    protected void onPause() {
        super.onPause();
        //mSensorManager.unregisterListener(this);
    }

    private void updateTimeAtEveryMin() {
        Timer t1 = new Timer();
        TimerTask tt1 = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Calendar cal = Calendar.getInstance();
                        SimpleDateFormat dateformat = new SimpleDateFormat("dd MMM yyyy");
                        SimpleDateFormat timeformat = new SimpleDateFormat("hh:mm aa");
                        String date = dateformat.format(cal.getTime());
                        String time = timeformat.format(cal.getTime());
                        timeTextView.setText(time+"\n"+date+" "+days[cal.get(Calendar.DAY_OF_WEEK) - 1] );
                    }
                });
            }

            ;
        };
        t1.scheduleAtFixedRate(tt1, 0, 1000);
    }

    private void setGaugeSpeedAndColors() {
        float max = 120.0f;
        float min = 20.0f;
        float factor = max - min;
        float gaugeSpeed = randomNum.nextFloat() * factor + min;
        ;
        if (gaugeSpeed <= 50.0f) {
            colorArr = new int[]{Color.GREEN};
            changeValArr = new float[]{gaugeSpeed};
        } else if (gaugeSpeed > 50.0f && gaugeSpeed <= 80.0f) {
            colorArr = new int[]{Color.GREEN, Color.YELLOW};
            changeValArr = new float[]{50.0f, gaugeSpeed};
        } else {
            colorArr = new int[]{Color.GREEN, Color.YELLOW, Color.RED};
            changeValArr = new float[]{50.0f, 80.0f, gaugeSpeed};
        }
        gaugeView.setSpeed(gaugeSpeed);
        gaugeView.setColors(colorArr);
        gaugeView.setChangeValues(changeValArr);
    }

    private void setBatteryValues() {
        batteryVal = batteryVal + 10;
        if (batteryVal == 100) {
            batteryVal = 0;
        }
        int currentVal = 100 - batteryVal;
        batteryView.setSpeed(currentVal);
        if (currentVal >= 75) {
            batteryView.setColors(new int[]{Color.GREEN});
        } else if (currentVal < 75 && currentVal >= 50) {
            batteryView.setColors(new int[]{Color.YELLOW});
        } else if (currentVal < 50 && currentVal >= 25) {
            batteryView.setColors(new int[]{Color.rgb(255, 127, 80)});
        } else {
            batteryView.setColors(new int[]{Color.RED});
        }
        batteryView.setChangeValues(new float[]{currentVal});
       /* final boolean isCharging  = (status == BatteryManager.BATTERY_STATUS_CHARGING)
                || (status == BatteryManager.BATTERY_STATUS_FULL);*/
        final boolean isCharging = false;
        //BatteryEvent batteryEvent = new BatteryEvent(currentVal,isCharging,status == BatteryManager.BATTERY_STATUS_FULL);
        mHorizontalBattery.setProgress(currentVal);
        mHorizontalBattery.setBatteryCharge(false);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        float ambient_temperature = sensorEvent.values[0];
        //temperature through String.valueOf(ambient_temperature) + getResources().getString(R.string.celsius));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    public String getLocation(){
        gpsTracker = new GpsTracker(MainActivity.this);
        if(gpsTracker.canGetLocation()){
            double latitude = gpsTracker.getLatitude();
            double longitude = gpsTracker.getLongitude();
            return getWeatherData(String.valueOf(latitude),String.valueOf(longitude));
        }else{
            //gpsTracker.showSettingsAlert();
        }
        return "";
    }

    public String getWeatherData(String latitude, String longitude) {
        HttpURLConnection con = null ;
        InputStream is = null;

        try {
            String url = "http://api.openweathermap.org/data/2.5/forecast/daily?lat=" + latitude + "&lon=" + longitude + "&cnt=10&mode=json";
            con = (HttpURLConnection) ( new URL(url)).openConnection();
            con.setRequestMethod("GET");
            con.setDoInput(true);
            con.setDoOutput(true);
            con.connect();

            StringBuffer buffer = null;
            try {
                buffer = new StringBuffer();
                is = con.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                String line = null;
                while ( (line = br.readLine()) != null )
                    buffer.append(line + "\r\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
            is.close();
            con.disconnect();
            JSONObject jObj = new JSONObject(buffer.toString());
            String cityName = getString("name", jObj);
            JSONObject mainObj = getObject("main", jObj);
            float temp = getFloat("temp", mainObj);
            return cityName + " "+ temp;
        }
        catch(Throwable t) {
            t.printStackTrace();
        }
        finally {
            try { is.close(); } catch(Throwable t) {}
            try { con.disconnect(); } catch(Throwable t) {}
        }
        return null;

    }

    private static float getFloat(String tagName, JSONObject jObj) throws JSONException {
        return (float) jObj.getDouble(tagName);
    }
    private static String getString(String tagName, JSONObject jObj) throws JSONException {
        return jObj.getString(tagName);
    }

    private static JSONObject getObject(String tagName, JSONObject jObj) throws JSONException {
        JSONObject subObj = jObj.getJSONObject(tagName);
        return subObj;
    }

    @Override
    protected void onStart() {
        super.onStart();
        // when we return to the app's gui we choose which fragment to start based on connection status
        if (global.getBluetoothCommunicator().getConnectedPeersList().size() == 0) {
            setFragment(DEFAULT_FRAGMENT);
        } else {
            setFragment(CONVERSATION_FRAGMENT);
        }
    }

    public void setFragment(int fragmentName) {
        switch (fragmentName) {
            case PAIRING_FRAGMENT: {
                // possible setting of the fragment
                if (getCurrentFragment() != PAIRING_FRAGMENT) {
                    PairingFragment paringFragment = new PairingFragment();
                    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE);
                    transaction.replace(R.id.fragment_container, paringFragment);
                    transaction.commit();
                    currentFragment = PAIRING_FRAGMENT;
                }
                break;
            }
            case CONVERSATION_FRAGMENT: {
                // possible setting of the fragment
                if (getCurrentFragment() != CONVERSATION_FRAGMENT) {
                    ConversationFragment conversationFragment = new ConversationFragment();
                    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                    transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                    transaction.replace(R.id.fragment_container, conversationFragment);
                    transaction.commit();
                    currentFragment = CONVERSATION_FRAGMENT;
                }
                break;
            }
        }
    }

    public int getCurrentFragment() {
        if (currentFragment != -1) {
            return currentFragment;
        } else {
            Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
            if (currentFragment != null) {
                if (currentFragment.getClass().equals(PairingFragment.class)) {
                    return PAIRING_FRAGMENT;
                }
                if (currentFragment.getClass().equals(ConversationFragment.class)) {
                    return CONVERSATION_FRAGMENT;
                }
            }
        }
        return -1;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //exitFromConversation();
//        DialogInterface.OnClickListener confirmExitListener = new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                exitFromConversation();
//            }
//        };
//        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
//        if (fragment != null) {
//            if (fragment instanceof ConversationFragment) {
//                showConfirmExitDialog(confirmExitListener);
//            } else {
//                super.onBackPressed();
//            }
//        } else {
//            super.onBackPressed();
//        }
    }

    public void exitFromConversation() {
        if (global.getBluetoothCommunicator().getConnectedPeersList().size() > 0) {
            Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
            if (fragment instanceof ConversationFragment) {
                ConversationFragment conversationFragment = (ConversationFragment) fragment;
                conversationFragment.appearLoading();
            }
            global.getBluetoothCommunicator().disconnectFromAll();
        } else {
            setFragment(DEFAULT_FRAGMENT);
        }
    }

    protected void showConfirmExitDialog(DialogInterface.OnClickListener confirmListener) {
        //creazione del dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setMessage("Confirm exit");
        builder.setPositiveButton(android.R.string.ok, confirmListener);
        builder.setNegativeButton(android.R.string.cancel, null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public int startSearch() {
        if (global.getBluetoothCommunicator().isBluetoothLeSupported() == BluetoothCommunicator.SUCCESS) {
            if (Tools.hasPermissions(this, REQUIRED_PERMISSIONS)) {
                int advertisingCode = global.getBluetoothCommunicator().startAdvertising();
                int discoveringCode = global.getBluetoothCommunicator().startDiscovery();
                if (advertisingCode == discoveringCode) {
                    return advertisingCode;
                }
                if (advertisingCode == BluetoothCommunicator.BLUETOOTH_LE_NOT_SUPPORTED || discoveringCode == BluetoothCommunicator.BLUETOOTH_LE_NOT_SUPPORTED) {
                    return BluetoothCommunicator.BLUETOOTH_LE_NOT_SUPPORTED;
                }
                if (advertisingCode == BluetoothCommunicator.SUCCESS || discoveringCode == BluetoothCommunicator.SUCCESS) {
                    if (advertisingCode == BluetoothCommunicator.ALREADY_STARTED || discoveringCode == BluetoothCommunicator.ALREADY_STARTED) {
                        return BluetoothCommunicator.SUCCESS;
                    }
                }
                return BluetoothCommunicator.ERROR;
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(REQUIRED_PERMISSIONS, REQUEST_CODE_REQUIRED_PERMISSIONS);
                }
                return NO_PERMISSIONS;
            }
        } else {
            return BluetoothCommunicator.BLUETOOTH_LE_NOT_SUPPORTED;
        }
    }

    public int stopSearch(boolean tryRestoreBluetoothStatus) {
        int advertisingCode = global.getBluetoothCommunicator().stopAdvertising(tryRestoreBluetoothStatus);
        int discoveringCode = global.getBluetoothCommunicator().stopDiscovery(tryRestoreBluetoothStatus);
        if (advertisingCode == discoveringCode) {
            return advertisingCode;
        }
        if (advertisingCode == BluetoothCommunicator.BLUETOOTH_LE_NOT_SUPPORTED || discoveringCode == BluetoothCommunicator.BLUETOOTH_LE_NOT_SUPPORTED) {
            return BluetoothCommunicator.BLUETOOTH_LE_NOT_SUPPORTED;
        }
        if (advertisingCode == BluetoothCommunicator.SUCCESS || discoveringCode == BluetoothCommunicator.SUCCESS) {
            if (advertisingCode == BluetoothCommunicator.ALREADY_STOPPED || discoveringCode == BluetoothCommunicator.ALREADY_STOPPED) {
                return BluetoothCommunicator.SUCCESS;
            }
        }
        return BluetoothCommunicator.ERROR;
    }

    public boolean isSearching() {
        return global.getBluetoothCommunicator().isAdvertising() && global.getBluetoothCommunicator().isDiscovering();
    }

    public void connect(Peer peer) {
        stopSearch(false);
        global.getBluetoothCommunicator().connect(peer);
    }

    public void acceptConnection(Peer peer) {
        global.getBluetoothCommunicator().acceptConnection(peer);
    }

    public void rejectConnection(Peer peer) {
        global.getBluetoothCommunicator().rejectConnection(peer);
    }

    public int disconnect(Peer peer) {
        return global.getBluetoothCommunicator().disconnect(peer);
    }

    public CoordinatorLayout getFragmentContainer() {
        return fragmentContainer;
    }



    public void addCallback(Callback callback) {
        // in this way the listener will listen to both this activity and the communicatorexample
        global.getBluetoothCommunicator().addCallback(callback);
        clientsCallbacks.add(callback);
    }

    public void removeCallback(Callback callback) {
        global.getBluetoothCommunicator().removeCallback(callback);
        clientsCallbacks.remove(callback);
    }

    private void notifyMissingSearchPermission() {
        for (int i = 0; i < clientsCallbacks.size(); i++) {
            clientsCallbacks.get(i).onMissingSearchPermission();
        }
    }

    private void notifySearchPermissionGranted() {
        for (int i = 0; i < clientsCallbacks.size(); i++) {
            clientsCallbacks.get(i).onSearchPermissionGranted();
        }
    }

    private void notifySearchStarted() {
        for (int i = 0; i < clientsCallbacks.size(); i++) {
            clientsCallbacks.get(i).onSearchStarted();
        }
    }

    private void notifySearchStopped() {
        for (int i = 0; i < clientsCallbacks.size(); i++) {
            clientsCallbacks.get(i).onSearchStopped();
        }
    }
    public static class Callback extends BluetoothCommunicator.Callback {
        public void onSearchStarted() {
        }

        public void onSearchStopped() {
        }

        public void onMissingSearchPermission() {
        }

        public void onSearchPermissionGranted() {
        }
    }

//    class RequestTask extends AsyncTask<String, String, String>{
//
//        @Override
//        protected String doInBackground(String... uri) {
//            Httpcl httpclient = new DefaultHttpClient();
//            HttpResponse response;
//            String responseString = null;
//            try {
//                response = httpclient.execute(new HttpGet(uri[0]));
//                StatusLine statusLine = response.getStatusLine();
//                if(statusLine.getStatusCode() == HttpStatus.SC_OK){
//                    ByteArrayOutputStream out = new ByteArrayOutputStream();
//                    response.getEntity().writeTo(out);
//                    responseString = out.toString();
//                    out.close();
//                } else{
//                    //Closes the connection.
//                    response.getEntity().getContent().close();
//                    throw new IOException(statusLine.getReasonPhrase());
//                }
//            } catch (ClientProtocolException e) {
//                //TODO Handle problems..
//            } catch (IOException e) {
//                //TODO Handle problems..
//            }
//            return responseString;
//        }
//
//        @Override
//        protected void onPostExecute(String result) {
//            super.onPostExecute(result);
//            //Do anything with response..
//        }
//    }

}
package com.bluetooth.communicatorexample;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import java.util.Objects;

public class CallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            String incoming_number = "";
            incoming_number = Objects.requireNonNull(intent.getExtras()).getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
            Toast.makeText(context,
                    "Incoming: " + incoming_number,
                    Toast.LENGTH_LONG).show();
            Log.i("incoming number on receive", incoming_number);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
